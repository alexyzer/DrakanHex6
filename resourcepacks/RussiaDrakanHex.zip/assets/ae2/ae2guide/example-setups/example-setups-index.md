---
navigation:
  title: Примеры установок
  position: 40
---

# Примеры установок

<SubPages />