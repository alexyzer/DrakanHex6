---
navigation:
  parent: items-blocks-machines-index.md
  title: Эндер-пыль
  icon: ender_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:ender_dust
---

# Эндер-пыль

<ItemImage id="ender_dust" scale="4" />

Эндер-жемчуг, измельчённый с помощью <ItemLink id="inscriber" />. Используется в производстве <ItemLink id="wireless_booster" /> и пар <ItemLink id="quantum_entangled_singularity" />.

## Рецепт

<RecipeFor id="ender_dust" />