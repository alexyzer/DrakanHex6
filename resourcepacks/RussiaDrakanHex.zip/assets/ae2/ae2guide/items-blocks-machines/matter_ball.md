---
navigation:
  parent: items-blocks-machines-index.md
  title: Шары материи
  icon: matter_ball
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:matter_ball
---

# Шары материи

<ItemImage id="matter_ball" scale="4" />

Шар из обычной материи, полезен как боеприпас для <ItemLink id="matter_cannon" /> или для создания [шариков краски](paintballs.md).

Создаётся из 256 предметов или вёдер в <ItemLink id="condenser" /> в режиме шаров материи.