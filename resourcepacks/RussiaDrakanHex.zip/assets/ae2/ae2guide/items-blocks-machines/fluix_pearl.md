---
navigation:
  parent: items-blocks-machines-index.md
  title: Флюисовая жемчужина
  icon: fluix_pearl
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_pearl
---

# Флюисовая жемчужина

<ItemImage id="fluix_pearl" scale="4" />

Эндер-жемчуг, покрытый <ItemLink id="fluix_crystal" />, используется в производстве нескольких компонентов AE2.

## Рецепт

<RecipeFor id="fluix_pearl" />