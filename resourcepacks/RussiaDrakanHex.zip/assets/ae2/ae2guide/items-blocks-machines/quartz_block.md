---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Блок истинного кварца
  icon: quartz_block
  position: 010
categories:
- прочие ингредиенты и блоки
item_ids:
- ae2:quartz_block
---

# Блок истинного кварца

<BlockImage id="quartz_block" scale="8" />

Блок для хранения <ItemLink id="certus_quartz_crystal" />. Может использоваться для создания [цветущих блоков истинного кварца](budding_certus.md) или [декоративных блоков истинного кварца](decorative_certus.md).

## Рецепт

<RecipeFor id="quartz_block" />