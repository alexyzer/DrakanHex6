---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Пыль истинного кварца
  icon: certus_quartz_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:certus_quartz_dust
---

# Пыль истинного кварца

<ItemImage id="certus_quartz_dust" scale="4" />

<ItemLink id="certus_quartz_crystal" />, измельчённый с помощью <ItemLink id="inscriber" />. Используется в производстве нескольких материалов и компонентов AE2.

## Рецепт

<RecipeFor id="certus_quartz_dust" />